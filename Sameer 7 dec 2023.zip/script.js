 var myLink = document.getElementById('myLink');

    myLink.addEventListener('mouseenter', function() {
     
      myLink.classList.add('glow');
    });

    myLink.addEventListener('mouseleave', function() {
      
      myLink.classList.remove('glow');
    });

 var myLink1 = document.getElementById('myLink1');

    myLink1.addEventListener('mouseenter', function() {
      
      myLink1.classList.add('glow');
    });

    myLink1.addEventListener('mouseleave', function() {
      
      myLink1.classList.remove('glow');
    }); 

 var myLink2 = document.getElementById('myLink2');

    myLink2.addEventListener('mouseenter', function() {
      
      myLink2.classList.add('glow');
    });

    myLink2.addEventListener('mouseleave', function() {
      
      myLink2.classList.remove('glow');
    });   
    
 var myLink3 = document.getElementById('myLink3');

    myLink3.addEventListener('mouseenter', function() {
     
      myLink3.classList.add('glow');
    });

    myLink3.addEventListener('mouseleave', function() {
      
      myLink3.classList.remove('glow');
    });   
    
 var myLink4 = document.getElementById('myLink4');

    myLink4.addEventListener('mouseenter', function() {
      
      myLink4.classList.add('glow');
    });

    myLink4.addEventListener('mouseleave', function() {
      
      myLink4.classList.remove('glow');
    });   
    

 var myLink5 = document.getElementById('myLink5');

    myLink5.addEventListener('mouseenter', function() {
      
      myLink5.classList.add('glow');
    });

    myLink5.addEventListener('mouseleave', function() {
     
      myLink5.classList.remove('glow');
    });  

 var myLink6 = document.getElementById('myLink6');

    myLink6.addEventListener('mouseenter', function() {
      
      myLink6.classList.add('glow');
    });

    myLink6.addEventListener('mouseleave', function() {
      
      myLink6.classList.remove('glow');
    }); 


 function goToAboutPage() {
      window.location.href = 'aboutpage.html';
    } 

 function goToFeaturePage() {
      window.location.href = 'feature.html';
    }  

 function goToclientPage() {
      window.location.href = 'client.html';
    }    

function goTocontactPage() {
      window.location.href = 'contact.html';
    } 
